import React, { useState } from 'react';
import { Tabs } from '../components/ui/Tabs';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import {
  Plus,
  Video,
  Mic,
  FileText,
  Calendar,
  Eye,
  MoreHorizontal } from
'lucide-react';
// Mock content data
const MOCK_CONTENT = [
{
  id: '1',
  title: 'Culte du Dimanche 12 Nov',
  type: 'VIDEO',
  views: 1250,
  date: '2023-11-12',
  status: 'PUBLISHED',
  author: 'Pasteur Principal'
},
{
  id: '2',
  title: 'La puissance de la foi',
  type: 'AUDIO',
  views: 850,
  date: '2023-11-10',
  status: 'PUBLISHED',
  author: 'Pasteur Adjoint'
},
{
  id: '3',
  title: 'Étude Biblique: Jean 3:16',
  type: 'ARTICLE',
  views: 450,
  date: '2023-11-08',
  status: 'DRAFT',
  author: 'Équipe Rédaction'
},
{
  id: '4',
  title: 'Concert de Louange',
  type: 'EVENT',
  views: 2100,
  date: '2023-12-25',
  status: 'PUBLISHED',
  author: 'Groupe Musical'
},
{
  id: '5',
  title: 'Témoignage de guérison',
  type: 'VIDEO',
  views: 3200,
  date: '2023-11-05',
  status: 'PUBLISHED',
  author: 'Membre'
}];

export function ContentPage() {
  const [activeTab, setActiveTab] = useState('all');
  const filteredContent =
  activeTab === 'all' ?
  MOCK_CONTENT :
  MOCK_CONTENT.filter((item) => item.type.toLowerCase() === activeTab);
  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'VIDEO':
        return <Video className="w-4 h-4 text-blue-500" />;
      case 'AUDIO':
        return <Mic className="w-4 h-4 text-purple-500" />;
      case 'ARTICLE':
        return <FileText className="w-4 h-4 text-orange-500" />;
      case 'EVENT':
        return <Calendar className="w-4 h-4 text-green-500" />;
      default:
        return <FileText className="w-4 h-4" />;
    }
  };
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Contenus</h1>
          <p className="text-gray-500">
            Gérez les publications de votre église.
          </p>
        </div>
        <Button leftIcon={<Plus className="w-4 h-4" />}>Nouveau contenu</Button>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-gray-100">
          <Tabs
            tabs={[
            {
              id: 'all',
              label: 'Tous'
            },
            {
              id: 'video',
              label: 'Vidéos'
            },
            {
              id: 'audio',
              label: 'Audios'
            },
            {
              id: 'article',
              label: 'Articles'
            },
            {
              id: 'event',
              label: 'Événements'
            }]
            }
            activeTab={activeTab}
            onChange={setActiveTab} />
          
        </div>

        <div className="divide-y divide-gray-100">
          {filteredContent.map((item) =>
          <div
            key={item.id}
            className="p-4 hover:bg-gray-50 transition-colors flex items-center justify-between group">
            
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-gray-100 flex items-center justify-center flex-shrink-0">
                  {getTypeIcon(item.type)}
                </div>
                <div>
                  <h3 className="font-medium text-gray-900 group-hover:text-orange-600 transition-colors">
                    {item.title}
                  </h3>
                  <div className="flex items-center gap-3 text-sm text-gray-500 mt-1">
                    <span>{item.author}</span>
                    <span>•</span>
                    <span>{item.date}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="hidden sm:flex items-center gap-2 text-sm text-gray-500">
                  <Eye className="w-4 h-4" />
                  <span>{item.views.toLocaleString()}</span>
                </div>
                <Badge
                variant={item.status === 'PUBLISHED' ? 'success' : 'warning'}>
                
                  {item.status === 'PUBLISHED' ? 'Publié' : 'Brouillon'}
                </Badge>
                <button className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100">
                  <MoreHorizontal className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>);

}