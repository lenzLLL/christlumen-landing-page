import React from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Tabs } from '../components/ui/Tabs';
import { Save, Upload } from 'lucide-react';
export function SettingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Paramètres</h1>
        <p className="text-gray-500">
          Gérez les informations de votre église et vos préférences.
        </p>
      </div>

      <Tabs
        tabs={[
        {
          id: 'general',
          label: 'Général'
        },
        {
          id: 'notifications',
          label: 'Notifications'
        },
        {
          id: 'security',
          label: 'Sécurité'
        },
        {
          id: 'integrations',
          label: 'Intégrations'
        }]
        }
        activeTab="general"
        onChange={() => {}} />
      

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Settings Form */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Informations de l'Église
            </h3>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  label="Nom de l'église"
                  placeholder="Ex: Église La Compassion"
                  defaultValue="Église La Compassion" />
                
                <Input
                  label="Code Église"
                  placeholder="CH001"
                  defaultValue="CH001"
                  disabled />
                
              </div>
              <Input
                label="Description"
                placeholder="Une brève description..." />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  label="Ville"
                  placeholder="Abidjan"
                  defaultValue="Abidjan" />
                
                <Input
                  label="Pays"
                  placeholder="Côte d'Ivoire"
                  defaultValue="Côte d'Ivoire" />
                
              </div>
              <Input
                label="Email de contact"
                placeholder="contact@eglise.com"
                type="email" />
              
              <Input label="Téléphone" placeholder="+225..." type="tel" />
            </div>
            <div className="mt-6 flex justify-end">
              <Button leftIcon={<Save className="w-4 h-4" />}>
                Enregistrer les modifications
              </Button>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Réseaux Sociaux
            </h3>
            <div className="space-y-4">
              <Input label="Facebook" placeholder="https://facebook.com/..." />
              <Input label="YouTube" placeholder="https://youtube.com/..." />
              <Input
                label="Instagram"
                placeholder="https://instagram.com/..." />
              
            </div>
            <div className="mt-6 flex justify-end">
              <Button variant="outline">Sauvegarder</Button>
            </div>
          </Card>
        </div>

        {/* Sidebar Settings (Logo, etc) */}
        <div className="space-y-6">
          <Card className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Logo de l'Église
            </h3>
            <div className="flex flex-col items-center text-center">
              <div className="w-32 h-32 rounded-full bg-gray-100 mb-4 flex items-center justify-center border-2 border-dashed border-gray-300">
                <Upload className="w-8 h-8 text-gray-400" />
              </div>
              <p className="text-sm text-gray-500 mb-4">
                PNG, JPG jusqu'à 2MB. Recommandé 500x500px.
              </p>
              <Button variant="outline" size="sm" className="w-full">
                Changer le logo
              </Button>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Préférences
            </h3>
            <div className="space-y-3">
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  className="rounded text-orange-600 focus:ring-orange-500"
                  defaultChecked />
                
                <span className="text-sm text-gray-700">
                  Notifications par email
                </span>
              </label>
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  className="rounded text-orange-600 focus:ring-orange-500"
                  defaultChecked />
                
                <span className="text-sm text-gray-700">
                  Rapports hebdomadaires
                </span>
              </label>
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  className="rounded text-orange-600 focus:ring-orange-500" />
                
                <span className="text-sm text-gray-700">
                  Mode sombre (Bêta)
                </span>
              </label>
            </div>
          </Card>
        </div>
      </div>
    </div>);

}