import React, { useEffect, useState, useRef } from 'react';
interface Tab {
  id: string;
  label: string;
  count?: number;
}
interface TabsProps {
  tabs: Tab[];
  activeTab: string;
  onChange: (id: string) => void;
}
export function Tabs({ tabs, activeTab, onChange }: TabsProps) {
  const [indicatorStyle, setIndicatorStyle] = useState({
    left: 0,
    width: 0
  });
  const tabsRef = useRef<(HTMLButtonElement | null)[]>([]);
  useEffect(() => {
    const activeIndex = tabs.findIndex((t) => t.id === activeTab);
    const activeElement = tabsRef.current[activeIndex];
    if (activeElement) {
      setIndicatorStyle({
        left: activeElement.offsetLeft,
        width: activeElement.offsetWidth
      });
    }
  }, [activeTab, tabs]);
  return (
    <div className="relative border-b border-gray-200">
      <div className="flex space-x-8 overflow-x-auto scrollbar-hide">
        {tabs.map((tab, index) =>
        <button
          key={tab.id}
          ref={(el) => tabsRef.current[index] = el}
          onClick={() => onChange(tab.id)}
          className={`
              group inline-flex items-center py-4 px-1 text-sm font-medium transition-colors duration-200 whitespace-nowrap
              ${activeTab === tab.id ? 'text-[#FF6B35]' : 'text-gray-500 hover:text-gray-700'}
            `}>
          
            {tab.label}
            {tab.count !== undefined &&
          <span
            className={`
                  ml-2.5 py-0.5 px-2.5 rounded-full text-xs font-medium transition-colors
                  ${activeTab === tab.id ? 'bg-[#FF6B35]/10 text-[#FF6B35]' : 'bg-gray-100 text-gray-600 group-hover:bg-gray-200'}
                `}>
            
                {tab.count}
              </span>
          }
          </button>
        )}
      </div>
      <div
        className="absolute bottom-0 h-0.5 bg-[#FF6B35] transition-all duration-300 ease-out"
        style={indicatorStyle} />
      
    </div>);

}