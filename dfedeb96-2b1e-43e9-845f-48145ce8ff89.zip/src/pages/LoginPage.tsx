import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { PhoneInput } from '../components/auth/PhoneInput';
import { OTPInput } from '../components/auth/OTPInput';
import { Button } from '../components/ui/Button';
import { useAuth } from '../hooks/useAuth';
import {
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Shield,
  Users,
  Radio } from
'lucide-react';
import { api, MOCK_USER } from '../utils/api';
export function LoginPage() {
  const [step, setStep] = useState<'PHONE' | 'OTP'>('PHONE');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();
  const handleSendOtp = async () => {
    if (phone.length < 8) {
      setError('Numéro de téléphone invalide');
      return;
    }
    setIsLoading(true);
    setError('');
    try {
      await api.auth.sendOtp(phone);
      setStep('OTP');
    } catch (err) {
      setError("Erreur lors de l'envoi du code");
    } finally {
      setIsLoading(false);
    }
  };
  const handleVerifyOtp = async (otp: string) => {
    setIsLoading(true);
    setError('');
    if (otp.length === 6) {
      try {
        await new Promise((resolve) => setTimeout(resolve, 800));
        localStorage.setItem('token', 'mock-bypass-token');
        try {
          await login(phone, otp);
        } catch (e) {
          if (MOCK_USER.role === 'SADMIN') {
            navigate('/dashboard/admin');
          } else {
            navigate('/dashboard/owner');
          }
          return;
        }
        if (MOCK_USER.role === 'SADMIN') {
          navigate('/dashboard/admin');
        } else {
          navigate('/dashboard/owner');
        }
      } catch (err) {
        setError('Erreur de connexion');
      } finally {
        setIsLoading(false);
      }
      return;
    }
    try {
      const user = await login(phone, otp);
      if (user.role === 'SADMIN') {
        navigate('/dashboard/admin');
      } else {
        navigate('/dashboard/owner');
      }
    } catch (err) {
      setError('Code OTP incorrect');
    } finally {
      setIsLoading(false);
    }
  };
  const highlights = [
  {
    icon: Users,
    text: '+500 églises connectées'
  },
  {
    icon: Radio,
    text: 'Contenus en direct'
  },
  {
    icon: Shield,
    text: 'Connexion sécurisée'
  }];

  return (
    <div className="min-h-screen flex w-full bg-white overflow-hidden">
      {/* Left Side - Photo & Brand */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-gray-900">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1438232992991-995b7058bbb3?auto=format&fit=crop&q=80&w=1200&h=1800"
            alt="Worship Community"
            className="w-full h-full object-cover opacity-50" />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/20" />
        </div>

        <div className="relative z-10 flex flex-col justify-between w-full p-16 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold tracking-wider">PHOTIZO</span>
          </div>

          <div className="space-y-8 max-w-lg">
            <h1 className="text-4xl font-bold leading-tight">
              Retrouvez votre communauté.
            </h1>
            <p className="text-lg text-white/80 leading-relaxed">
              Accédez à votre espace de gestion, suivez vos membres et restez
              connecté avec votre église.
            </p>

            <div className="space-y-3">
              {highlights.map((item, index) =>
              <motion.div
                key={index}
                initial={{
                  opacity: 0,
                  x: -20
                }}
                animate={{
                  opacity: 1,
                  x: 0
                }}
                transition={{
                  delay: 0.3 + index * 0.15,
                  duration: 0.4
                }}
                className="flex items-center gap-3">
                
                  <div className="w-8 h-8 rounded-lg bg-white/10 backdrop-blur-sm flex items-center justify-center flex-shrink-0">
                    <item.icon className="w-4 h-4 text-[#FF6B35]" />
                  </div>
                  <span className="text-white/90">{item.text}</span>
                </motion.div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-4 text-sm text-white/50">
            <span>© 2026 Photizo App</span>
            <span className="w-1 h-1 bg-white/30 rounded-full"></span>
            <span>Confidentialité</span>
            <span className="w-1 h-1 bg-white/30 rounded-full"></span>
            <span>Conditions</span>
          </div>
        </div>
      </div>

      {/* Right Side - Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12 bg-white relative">
        {/* Mobile Header Background */}
        <div className="lg:hidden absolute top-0 left-0 w-full h-40 overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1438232992991-995b7058bbb3?auto=format&fit=crop&q=80&w=800&h=400"
            alt=""
            className="w-full h-full object-cover" />
          
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 to-white" />
        </div>

        <div className="w-full max-w-md space-y-8 relative z-10">
          <div className="text-center lg:text-left">
            <motion.div
              initial={{
                opacity: 0,
                y: 20
              }}
              animate={{
                opacity: 1,
                y: 0
              }}
              transition={{
                duration: 0.5
              }}>
              
              <div className="flex justify-center lg:justify-start mb-6">
                <img
                  src="/ChatGPT_Image_14_janv._2026,_15_43_53.png"
                  alt="PHOTIZO"
                  className="h-16 w-auto drop-shadow-sm bg-white rounded-xl p-1" />
                
              </div>

              <h2 className="text-3xl font-bold text-gray-900 tracking-tight">
                {step === 'PHONE' ? 'Bon retour !' : 'Vérification'}
              </h2>
              <p className="mt-2 text-gray-500">
                {step === 'PHONE' ?
                'Entrez votre numéro pour accéder à votre espace' :
                `Code envoyé au +225 ${phone}`}
              </p>
            </motion.div>
          </div>

          <div className="mt-8">
            <AnimatePresence mode="wait">
              {step === 'PHONE' ?
              <motion.div
                key="phone-step"
                initial={{
                  opacity: 0,
                  x: 20
                }}
                animate={{
                  opacity: 1,
                  x: 0
                }}
                exit={{
                  opacity: 0,
                  x: -20
                }}
                transition={{
                  duration: 0.3
                }}
                className="space-y-6">
                
                  <PhoneInput value={phone} onChange={setPhone} error={error} />

                  <Button
                  className="w-full h-12 text-base shadow-lg shadow-orange-500/20 hover:shadow-orange-500/30 transition-all duration-300"
                  onClick={handleSendOtp}
                  isLoading={isLoading}
                  rightIcon={<ArrowRight className="w-5 h-5 ml-1" />}>
                  
                    Continuer
                  </Button>

                  <div className="text-center pt-4">
                    <p className="text-sm text-gray-600">
                      Pas encore de compte ?{' '}
                      <Link
                      to="/signup"
                      className="font-semibold text-[#FF6B35] hover:text-[#E91E63] transition-colors">
                      
                        S'inscrire gratuitement
                      </Link>
                    </p>
                  </div>
                </motion.div> :

              <motion.div
                key="otp-step"
                initial={{
                  opacity: 0,
                  x: 20
                }}
                animate={{
                  opacity: 1,
                  x: 0
                }}
                exit={{
                  opacity: 0,
                  x: -20
                }}
                transition={{
                  duration: 0.3
                }}
                className="space-y-8">
                
                  <div className="bg-orange-50 rounded-xl p-4 border border-orange-100">
                    <OTPInput onComplete={handleVerifyOtp} error={error} />
                  </div>

                  <div className="flex flex-col space-y-4">
                    <Button
                    variant="outline"
                    className="w-full h-12 border-gray-200 text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                    onClick={() => setStep('PHONE')}>
                    
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Modifier le numéro
                    </Button>

                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-500">Code non reçu ?</span>
                      <button
                      className="text-[#FF6B35] hover:text-[#E91E63] font-semibold transition-colors"
                      onClick={handleSendOtp}
                      disabled={isLoading}>
                      
                        Renvoyer le code
                      </button>
                    </div>
                  </div>

                  <div className="text-center">
                    <p className="text-xs text-green-600 font-medium bg-green-50 py-2 px-3 rounded-lg inline-flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                      Mode Test: Entrez n'importe quel code à 6 chiffres
                    </p>
                  </div>
                </motion.div>
              }
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>);

}