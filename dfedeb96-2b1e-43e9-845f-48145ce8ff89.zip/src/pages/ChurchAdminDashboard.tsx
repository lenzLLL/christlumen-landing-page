import React from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import {
  Users,
  FileText,
  Calendar,
  TrendingUp,
  Plus,
  ArrowRight } from
'lucide-react';
import { Link } from 'react-router-dom';
export function ChurchAdminDashboard() {
  const stats = [
  {
    label: 'Membres Actifs',
    value: '1,250',
    change: '+12%',
    icon: Users,
    color: 'bg-blue-500',
    link: '/dashboard/church-admin/members'
  },
  {
    label: 'Contenus Publiés',
    value: '342',
    change: '+5%',
    icon: FileText,
    color: 'bg-purple-500',
    link: '/dashboard/church-admin/content'
  },
  {
    label: 'Événements à venir',
    value: '3',
    change: 'Cette semaine',
    icon: Calendar,
    color: 'bg-orange-500',
    link: '/dashboard/church-admin/events'
  },
  {
    label: 'Dons du mois',
    value: '2.4M',
    change: '+8%',
    icon: TrendingUp,
    color: 'bg-green-500',
    link: '/dashboard/church-admin/finances'
  }];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Tableau de bord</h1>
          <p className="text-gray-500">
            Bienvenue, Administrateur. Voici ce qui se passe dans votre église.
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" leftIcon={<Plus className="w-4 h-4" />}>
            Nouveau Contenu
          </Button>
          <Button leftIcon={<Plus className="w-4 h-4" />}>
            Nouvel Événement
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) =>
        <Link to={stat.link} key={index} className="block group">
            <Card className="p-6 hover:shadow-md transition-all duration-200 border-gray-200 group-hover:border-orange-200">
              <div className="flex items-center justify-between mb-4">
                <div
                className={`p-3 rounded-xl ${stat.color} bg-opacity-10 group-hover:bg-opacity-20 transition-colors`}>
                
                  <stat.icon
                  className={`w-6 h-6 ${stat.color.replace('bg-', 'text-')}`} />
                
                </div>
                <span className="text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full">
                  {stat.change}
                </span>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">
                  {stat.label}
                </p>
                <h3 className="text-2xl font-bold text-gray-900 mt-1">
                  {stat.value}
                </h3>
              </div>
            </Card>
          </Link>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Activity / Content */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-gray-900">
              Contenus Récents
            </h2>
            <Link
              to="/dashboard/church-admin/content"
              className="text-sm text-orange-600 hover:text-orange-700 font-medium flex items-center">
              
              Voir tout <ArrowRight className="w-4 h-4 ml-1" />
            </Link>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 shadow-sm divide-y divide-gray-100">
            {[1, 2, 3].map((i) =>
            <div
              key={i}
              className="p-4 flex items-center gap-4 hover:bg-gray-50 transition-colors">
              
                <div className="w-16 h-10 bg-gray-100 rounded-lg flex-shrink-0"></div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-gray-900 truncate">
                    Culte de louange et adoration - Dimanche 12 Nov
                  </h4>
                  <p className="text-sm text-gray-500">
                    Publié il y a 2 jours • 1.2k vues
                  </p>
                </div>
                <div className="text-sm font-medium text-green-600">Publié</div>
              </div>
            )}
          </div>
        </div>

        {/* Upcoming Events */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-gray-900">
              Prochains Événements
            </h2>
            <Link
              to="/dashboard/church-admin/events"
              className="text-sm text-orange-600 hover:text-orange-700 font-medium">
              
              Calendrier
            </Link>
          </div>

          <div className="space-y-4">
            {[1, 2].map((i) =>
            <Card key={i} className="p-4 border-l-4 border-l-orange-500">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-xs font-bold text-orange-600 uppercase tracking-wider">
                    Demain
                  </span>
                  <span className="text-xs text-gray-500">19:00</span>
                </div>
                <h4 className="font-bold text-gray-900 mb-1">
                  Soirée de Prière
                </h4>
                <p className="text-sm text-gray-500 flex items-center">
                  <Users className="w-3 h-3 mr-1" /> 150 participants
                </p>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>);

}