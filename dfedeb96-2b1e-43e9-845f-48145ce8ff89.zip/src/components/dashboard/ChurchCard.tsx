import React from 'react';
import { Church } from '../../types';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Users, MapPin, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '../ui/Button';
interface ChurchCardProps {
  church: Church;
}
export function ChurchCard({ church }: ChurchCardProps) {
  const statusVariants = {
    APPROVED: 'success',
    PENDING: 'warning',
    REJECTED: 'error'
  } as const;
  return (
    <Card className="h-full flex flex-col">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <img
            src={
            church.logoUrl ||
            `https://ui-avatars.com/api/?name=${church.title}&background=random`
            }
            alt={church.title}
            className="w-12 h-12 rounded-lg object-cover shadow-sm" />
          
          <div>
            <h3 className="font-semibold text-gray-900 line-clamp-1">
              {church.title}
            </h3>
            <p className="text-xs text-gray-500">{church.code}</p>
          </div>
        </div>
        <Badge variant={statusVariants[church.status]}>{church.status}</Badge>
      </div>

      <div className="space-y-3 flex-1">
        <div className="flex items-center text-sm text-gray-600">
          <Users className="w-4 h-4 mr-2 text-gray-400" />
          {church.membersCount} membres
        </div>
        <div className="flex items-center text-sm text-gray-600">
          <MapPin className="w-4 h-4 mr-2 text-gray-400" />
          {church.city}, {church.country}
        </div>
        {church.description &&
        <p className="text-sm text-gray-500 line-clamp-2 mt-2">
            {church.description}
          </p>
        }
      </div>

      <div className="mt-6 pt-4 border-t border-gray-50">
        <Link to={`/dashboard/owner/church/${church.id}`}>
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            rightIcon={<ArrowRight className="w-4 h-4" />}>
            
            Gérer l'église
          </Button>
        </Link>
      </div>
    </Card>);

}