import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Tabs } from '../components/ui/Tabs';
import { MemberTable } from '../components/dashboard/MemberTable';
import { ContentList } from '../components/dashboard/ContentList';
import { Button } from '../components/ui/Button';
import { Settings, Share2 } from 'lucide-react';
export function ChurchDetailPage() {
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState('overview');
  const tabs = [
  {
    id: 'overview',
    label: "Vue d'ensemble"
  },
  {
    id: 'members',
    label: 'Membres',
    count: 1250
  },
  {
    id: 'content',
    label: 'Contenus',
    count: 45
  },
  {
    id: 'events',
    label: 'Événements'
  },
  {
    id: 'donations',
    label: 'Dons'
  }];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <img
              src="https://images.unsplash.com/photo-1548625361-18886594294d?auto=format&fit=crop&q=80&w=150&h=150"
              alt="Church Logo"
              className="w-16 h-16 rounded-xl object-cover shadow-sm" />
            
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                Église La Compassion
              </h1>
              <p className="text-gray-500 flex items-center gap-2">
                Abidjan, Côte d'Ivoire •{' '}
                <span className="text-green-600 font-medium">Approuvée</span>
              </p>
            </div>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" leftIcon={<Share2 className="w-4 h-4" />}>
              Partager
            </Button>
            <Button
              variant="secondary"
              leftIcon={<Settings className="w-4 h-4" />}>
              
              Paramètres
            </Button>
          </div>
        </div>

        <div className="mt-8">
          <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />
        </div>
      </div>

      {/* Content Area */}
      <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
        {activeTab === 'overview' &&
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <h3 className="font-semibold text-gray-900 mb-4">
                  Activité Récente
                </h3>
                <p className="text-gray-500 text-sm">
                  Graphique d'activité ici...
                </p>
              </div>
            </div>
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <h3 className="font-semibold text-gray-900 mb-4">
                  Prochain Événement
                </h3>
                <div className="bg-purple-50 p-4 rounded-lg border border-purple-100">
                  <p className="font-medium text-purple-900">
                    Culte de louange
                  </p>
                  <p className="text-sm text-purple-700 mt-1">
                    Dimanche, 09:00
                  </p>
                </div>
              </div>
            </div>
          </div>
        }

        {activeTab === 'members' && <MemberTable />}
        {activeTab === 'content' && <ContentList />}
        {activeTab === 'events' &&
        <div className="text-center py-12 text-gray-500">
            Module Événements à venir
          </div>
        }
        {activeTab === 'donations' &&
        <div className="text-center py-12 text-gray-500">
            Module Dons à venir
          </div>
        }
      </div>
    </div>);

}