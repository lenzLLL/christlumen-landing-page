import React, { useState } from 'react';
import { Table } from '../components/ui/Table';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Plus, Search, Filter, MoreVertical, Mail, Ban } from 'lucide-react';
// Mock data for members
const MOCK_MEMBERS = [
{
  id: '1',
  name: 'Jean Kouassi',
  email: 'jean.k@example.com',
  role: 'Membre',
  status: 'ACTIVE',
  joinedAt: '2023-01-15',
  avatar: 'https://i.pravatar.cc/150?u=1'
},
{
  id: '2',
  name: 'Marie Doumbia',
  email: 'marie.d@example.com',
  role: 'Modérateur',
  status: 'ACTIVE',
  joinedAt: '2023-02-20',
  avatar: 'https://i.pravatar.cc/150?u=2'
},
{
  id: '3',
  name: 'Paul Konan',
  email: 'paul.k@example.com',
  role: 'Admin',
  status: 'ACTIVE',
  joinedAt: '2022-11-05',
  avatar: 'https://i.pravatar.cc/150?u=3'
},
{
  id: '4',
  name: 'Sarah Yapo',
  email: 'sarah.y@example.com',
  role: 'Membre',
  status: 'BANNED',
  joinedAt: '2023-03-10',
  avatar: 'https://i.pravatar.cc/150?u=4'
},
{
  id: '5',
  name: 'Michel Zahui',
  email: 'michel.z@example.com',
  role: 'Membre',
  status: 'ACTIVE',
  joinedAt: '2023-04-01',
  avatar: 'https://i.pravatar.cc/150?u=5'
}];

export function MembersPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const filteredMembers = MOCK_MEMBERS.filter(
    (member) =>
    member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.email.toLowerCase().includes(searchTerm.toLowerCase())
  );
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Membres</h1>
          <p className="text-gray-500">
            Gérez les membres de votre communauté.
          </p>
        </div>
        <Button leftIcon={<Plus className="w-4 h-4" />}>
          Ajouter un membre
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4 bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Rechercher un membre..."
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)} />
          
        </div>
        <Button variant="outline" leftIcon={<Filter className="w-4 h-4" />}>
          Filtres
        </Button>
      </div>

      {/* Members Table */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <Table
          data={filteredMembers}
          keyExtractor={(item) => item.id}
          columns={[
          {
            header: 'Membre',
            accessor: (item) =>
            <div className="flex items-center gap-3">
                  <img
                src={item.avatar}
                alt={item.name}
                className="w-10 h-10 rounded-full object-cover bg-gray-100" />
              
                  <div>
                    <p className="font-medium text-gray-900">{item.name}</p>
                    <p className="text-sm text-gray-500">{item.email}</p>
                  </div>
                </div>

          },
          {
            header: 'Rôle',
            accessor: (item) =>
            <Badge
              variant={
              item.role === 'Admin' ?
              'primary' :
              item.role === 'Modérateur' ?
              'warning' :
              'default'
              }>
              
                  {item.role}
                </Badge>

          },
          {
            header: 'Statut',
            accessor: (item) =>
            <Badge
              variant={item.status === 'ACTIVE' ? 'success' : 'danger'}>
              
                  {item.status === 'ACTIVE' ? 'Actif' : 'Banni'}
                </Badge>

          },
          {
            header: "Date d'adhésion",
            accessor: 'joinedAt'
          },
          {
            header: 'Actions',
            accessor: () =>
            <div className="flex justify-end gap-2">
                  <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-50 rounded-lg transition-colors">
                    <Mail className="w-4 h-4" />
                  </button>
                  <button className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                    <Ban className="w-4 h-4" />
                  </button>
                  <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-50 rounded-lg transition-colors">
                    <MoreVertical className="w-4 h-4" />
                  </button>
                </div>,

            className: 'text-right'
          }]
          } />
        
      </div>
    </div>);

}