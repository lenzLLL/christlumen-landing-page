import React from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Calendar, PlayCircle, Heart, MapPin, Clock } from 'lucide-react';
export function MemberDashboard() {
  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-[#FF6B35] to-[#E91E63] rounded-2xl p-8 text-white shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-10 rounded-full -mr-16 -mt-16 blur-2xl"></div>
        <div className="relative z-10">
          <h1 className="text-3xl font-bold mb-2">Bienvenue, Jean !</h1>
          <p className="text-white/90 max-w-xl text-lg">
            Heureux de vous retrouver. Voici les dernières nouvelles de votre
            communauté.
          </p>
          <div className="mt-6 flex gap-3">
            <Button className="bg-white text-[#E91E63] hover:bg-gray-50 border-none">
              Faire un don
            </Button>
            <Button
              variant="outline"
              className="text-white border-white hover:bg-white/10">
              
              Mon profil
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Feed */}
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-xl font-bold text-gray-900">
            Dernières publications
          </h2>

          {/* Featured Video */}
          <Card className="overflow-hidden group cursor-pointer hover:shadow-md transition-all">
            <div className="relative aspect-video bg-gray-900">
              <img
                src="https://images.unsplash.com/photo-1438232992991-995b7058bbb3?auto=format&fit=crop&q=80&w=1000"
                alt="Cover"
                className="w-full h-full object-cover opacity-80 group-hover:opacity-60 transition-opacity" />
              
              <div className="absolute inset-0 flex items-center justify-center">
                <PlayCircle className="w-16 h-16 text-white opacity-90 group-hover:scale-110 transition-transform duration-300" />
              </div>
              <div className="absolute bottom-4 left-4 right-4">
                <Badge className="bg-red-600 text-white border-none mb-2">
                  LIVE
                </Badge>
                <h3 className="text-white text-xl font-bold">
                  Culte de Dimanche - La Puissance de la Foi
                </h3>
              </div>
            </div>
            <div className="p-4 flex justify-between items-center">
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <span>Il y a 2 heures</span>
                <span>•</span>
                <span>1.2k vues</span>
              </div>
              <Button size="sm" variant="ghost">
                Partager
              </Button>
            </div>
          </Card>

          {/* Article Card */}
          <Card className="p-6 hover:shadow-md transition-shadow cursor-pointer">
            <div className="flex gap-4">
              <div className="flex-1">
                <Badge variant="primary" className="mb-2">
                  Étude Biblique
                </Badge>
                <h3 className="text-lg font-bold text-gray-900 mb-2">
                  Comprendre les Écritures : Partie 1
                </h3>
                <p className="text-gray-600 line-clamp-2 mb-4">
                  Une analyse approfondie des textes sacrés pour mieux
                  comprendre le contexte historique et spirituel...
                </p>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <div className="w-6 h-6 rounded-full bg-gray-200"></div>
                  <span>Pasteur Principal</span>
                  <span>•</span>
                  <span>5 min de lecture</span>
                </div>
              </div>
              <div className="w-24 h-24 bg-gray-100 rounded-lg flex-shrink-0 hidden sm:block"></div>
            </div>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Upcoming Events */}
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-4">À venir</h2>
            <div className="space-y-4">
              {[1, 2].map((i) =>
              <Card
                key={i}
                className="p-4 hover:border-orange-200 transition-colors cursor-pointer">
                
                  <div className="flex gap-4">
                    <div className="flex flex-col items-center justify-center w-12 h-12 bg-orange-50 rounded-lg text-orange-600 flex-shrink-0">
                      <span className="text-xs font-bold uppercase">NOV</span>
                      <span className="text-lg font-bold">19</span>
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900">
                        Soirée de Louange
                      </h4>
                      <div className="flex items-center text-xs text-gray-500 mt-1">
                        <Clock className="w-3 h-3 mr-1" /> 19:00
                        <span className="mx-1">•</span>
                        <MapPin className="w-3 h-3 mr-1" /> Grand Hall
                      </div>
                    </div>
                  </div>
                </Card>
              )}
            </div>
          </div>

          {/* Giving Summary */}
          <Card className="p-6 bg-gradient-to-br from-gray-900 to-gray-800 text-white border-none">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-white/10 rounded-lg">
                <Heart className="w-5 h-5 text-pink-400" />
              </div>
              <h3 className="font-bold">Mes Dons</h3>
            </div>
            <p className="text-gray-400 text-sm mb-1">Total ce mois</p>
            <p className="text-2xl font-bold mb-4">25,000 FCFA</p>
            <Button className="w-full bg-white text-gray-900 hover:bg-gray-100 border-none">
              Faire un don
            </Button>
          </Card>
        </div>
      </div>
    </div>);

}