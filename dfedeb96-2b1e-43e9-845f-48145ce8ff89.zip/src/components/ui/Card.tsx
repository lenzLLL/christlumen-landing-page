import React from 'react';
interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
  description?: string;
  footer?: React.ReactNode;
  onClick?: () => void;
}
export function Card({
  children,
  className = '',
  title,
  description,
  footer,
  onClick
}: CardProps) {
  return (
    <div
      className={`
        bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden
        ${onClick ? 'cursor-pointer hover:shadow-md hover:border-gray-200 transition-all duration-200' : ''}
        ${className}
      `}
      onClick={onClick}>
      
      {(title || description) &&
      <div className="px-6 py-5 border-b border-gray-50">
          {title &&
        <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
        }
          {description &&
        <p className="mt-1 text-sm text-gray-500">{description}</p>
        }
        </div>
      }
      <div className="px-6 py-5">{children}</div>
      {footer &&
      <div className="px-6 py-4 bg-gray-50 border-t border-gray-100">
          {footer}
        </div>
      }
    </div>);

}