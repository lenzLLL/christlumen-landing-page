import React from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate } from
'react-router-dom';
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';
import { DashboardPage } from './pages/DashboardPage';
import { OwnerDashboard } from './pages/OwnerDashboard';
import { ChurchDetailPage } from './pages/ChurchDetailPage';
import { AdminDashboard } from './pages/AdminDashboard';
import { ChurchAdminDashboard } from './pages/ChurchAdminDashboard';
import { ModeratorDashboard } from './pages/ModeratorDashboard';
import { MemberDashboard } from './pages/MemberDashboard';
import { MembersPage } from './pages/MembersPage';
import { ContentPage } from './pages/ContentPage';
import { EventsPage } from './pages/EventsPage';
import { FinancesPage } from './pages/FinancesPage';
import { SettingsPage } from './pages/SettingsPage';
import { ContentModerationPage } from './pages/ContentModerationPage';
import { useAuth } from './hooks/useAuth';
// Protected Route Wrapper
function ProtectedRoute({
  children,
  allowedRoles



}: {children: React.ReactNode;allowedRoles?: string[];}) {
  const { isAuthenticated, user, loading } = useAuth();
  if (loading)
  return (
    <div className="min-h-screen flex items-center justify-center">
        Chargement...
      </div>);

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  if (allowedRoles && user && !allowedRoles.includes(user.role)) {
    // Redirect to appropriate dashboard based on role
    if (user.role === 'SADMIN')
    return <Navigate to="/dashboard/admin" replace />;
    if (user.role === 'OWNER') return <Navigate to="/dashboard/owner" replace />;
    if (user.role === 'ADMIN')
    return <Navigate to="/dashboard/church-admin" replace />;
    if (user.role === 'MODERATOR')
    return <Navigate to="/dashboard/moderator" replace />;
    if (user.role === 'USER') return <Navigate to="/dashboard/member" replace />;
    return <Navigate to="/dashboard" replace />;
  }
  return <>{children}</>;
}
// Redirect helper component
function DashboardRedirect() {
  const { user, loading } = useAuth();
  if (loading) return <div>Chargement...</div>;
  if (!user) return <Navigate to="/login" replace />;
  switch (user.role) {
    case 'SADMIN':
      return <Navigate to="/dashboard/owner" replace />;
    case 'OWNER':
      return <Navigate to="/dashboard/admin" replace />;
    case 'ADMIN':
      return <Navigate to="/dashboard/church-admin" replace />;
    case 'MODERATOR':
      return <Navigate to="/dashboard/moderator" replace />;
    case 'USER':
      return <Navigate to="/dashboard/member" replace />;
    default:
      return <Navigate to="/login" replace />;
  }
}
export function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />

        <Route
          path="/dashboard"
          element={
          <ProtectedRoute>
              <DashboardPage />
            </ProtectedRoute>
          }>
          
          {/* Main Dashboard Redirect */}
          <Route index element={<DashboardRedirect />} />

          {/* SADMIN Routes */}
          <Route
            path="admin"
            element={
            <ProtectedRoute allowedRoles={['SADMIN']}>
                <AdminDashboard />
              </ProtectedRoute>
            } />
          
          {/* Add more admin routes here */}

          {/* OWNER Routes */}
          <Route
            path="owner"
            element={
            <ProtectedRoute allowedRoles={['OWNER']}>
                <OwnerDashboard />
              </ProtectedRoute>
            } />
          
          <Route
            path="owner/church/:id"
            element={
            <ProtectedRoute allowedRoles={['OWNER']}>
                <ChurchDetailPage />
              </ProtectedRoute>
            } />
          
          <Route
            path="owner/churches"
            element={
            <ProtectedRoute allowedRoles={['OWNER']}>
                <OwnerDashboard />
              </ProtectedRoute>
            } />
          
          <Route
            path="owner/members"
            element={
            <ProtectedRoute allowedRoles={['OWNER']}>
                <MembersPage />
              </ProtectedRoute>
            } />
          
          <Route
            path="owner/content"
            element={
            <ProtectedRoute allowedRoles={['OWNER']}>
                <ContentPage />
              </ProtectedRoute>
            } />
          
          <Route
            path="owner/events"
            element={
            <ProtectedRoute allowedRoles={['OWNER']}>
                <EventsPage />
              </ProtectedRoute>
            } />
          
          <Route
            path="owner/finances"
            element={
            <ProtectedRoute allowedRoles={['OWNER']}>
                <FinancesPage />
              </ProtectedRoute>
            } />
          
          <Route
            path="owner/settings"
            element={
            <ProtectedRoute allowedRoles={['OWNER']}>
                <SettingsPage />
              </ProtectedRoute>
            } />
          

          {/* CHURCH ADMIN Routes */}
          <Route
            path="church-admin"
            element={
            <ProtectedRoute allowedRoles={['ADMIN']}>
                <ChurchAdminDashboard />
              </ProtectedRoute>
            } />
          
          <Route
            path="church-admin/members"
            element={
            <ProtectedRoute allowedRoles={['ADMIN']}>
                <MembersPage />
              </ProtectedRoute>
            } />
          
          <Route
            path="church-admin/content"
            element={
            <ProtectedRoute allowedRoles={['ADMIN']}>
                <ContentPage />
              </ProtectedRoute>
            } />
          
          <Route
            path="church-admin/events"
            element={
            <ProtectedRoute allowedRoles={['ADMIN']}>
                <EventsPage />
              </ProtectedRoute>
            } />
          
          <Route
            path="church-admin/finances"
            element={
            <ProtectedRoute allowedRoles={['ADMIN']}>
                <FinancesPage />
              </ProtectedRoute>
            } />
          
          <Route
            path="church-admin/settings"
            element={
            <ProtectedRoute allowedRoles={['ADMIN']}>
                <SettingsPage />
              </ProtectedRoute>
            } />
          

          {/* MODERATOR Routes */}
          <Route
            path="moderator"
            element={
            <ProtectedRoute allowedRoles={['MODERATOR']}>
                <ModeratorDashboard />
              </ProtectedRoute>
            } />
          
          <Route
            path="moderator/content-moderation"
            element={
            <ProtectedRoute allowedRoles={['MODERATOR']}>
                <ContentModerationPage />
              </ProtectedRoute>
            } />
          
          <Route
            path="moderator/reports"
            element={
            <ProtectedRoute allowedRoles={['MODERATOR']}>
                <ContentModerationPage />
              </ProtectedRoute>
            } />
          

          {/* MEMBER Routes */}
          <Route
            path="member"
            element={
            <ProtectedRoute allowedRoles={['USER']}>
                <MemberDashboard />
              </ProtectedRoute>
            } />
          
          <Route
            path="member/events"
            element={
            <ProtectedRoute allowedRoles={['USER']}>
                <EventsPage />
              </ProtectedRoute>
            } />
          
          <Route
            path="member/giving"
            element={
            <ProtectedRoute allowedRoles={['USER']}>
                <FinancesPage />
              </ProtectedRoute>
            } />
          
          <Route
            path="member/profile"
            element={
            <ProtectedRoute allowedRoles={['USER']}>
                <SettingsPage />
              </ProtectedRoute>
            } />
          
        </Route>
      </Routes>
    </Router>);

}