import React from 'react';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Plus, Calendar, MapPin, Users, Clock } from 'lucide-react';
const EVENTS = [
{
  id: '1',
  title: 'Culte de Louange',
  date: 'Dimanche 19 Nov',
  time: '09:00 - 11:30',
  location: 'Sanctuaire Principal',
  attendees: 450,
  status: 'UPCOMING',
  image:
  'https://images.unsplash.com/photo-1438232992991-995b7058bbb3?auto=format&fit=crop&q=80&w=500'
},
{
  id: '2',
  title: 'Nuit de Prière',
  date: 'Vendredi 24 Nov',
  time: '22:00 - 05:00',
  location: 'Salle Polyvalente',
  attendees: 120,
  status: 'UPCOMING',
  image:
  'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&q=80&w=500'
},
{
  id: '3',
  title: 'Séminaire des Jeunes',
  date: 'Samedi 25 Nov',
  time: '14:00 - 17:00',
  location: 'Auditorium Jeunesse',
  attendees: 85,
  status: 'PLANNED',
  image:
  'https://images.unsplash.com/photo-1523580494863-6f3031224c94?auto=format&fit=crop&q=80&w=500'
}];

export function EventsPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Événements</h1>
          <p className="text-gray-500">
            Planifiez et gérez les événements à venir.
          </p>
        </div>
        <Button leftIcon={<Plus className="w-4 h-4" />}>
          Créer un événement
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {EVENTS.map((event) =>
        <Card
          key={event.id}
          className="overflow-hidden flex flex-col group hover:shadow-md transition-shadow">
          
            <div className="h-48 relative">
              <img
              src={event.image}
              alt={event.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
            
              <div className="absolute top-4 right-4">
                <Badge
                variant={event.status === 'UPCOMING' ? 'success' : 'default'}
                className="bg-white/90 backdrop-blur-sm shadow-sm">
                
                  {event.status === 'UPCOMING' ? 'Bientôt' : 'Planifié'}
                </Badge>
              </div>
            </div>

            <div className="p-5 flex-1 flex flex-col">
              <h3 className="text-lg font-bold text-gray-900 mb-2">
                {event.title}
              </h3>

              <div className="space-y-3 mb-6 flex-1">
                <div className="flex items-center text-gray-600 text-sm">
                  <Calendar className="w-4 h-4 mr-2 text-orange-500" />
                  {event.date}
                </div>
                <div className="flex items-center text-gray-600 text-sm">
                  <Clock className="w-4 h-4 mr-2 text-orange-500" />
                  {event.time}
                </div>
                <div className="flex items-center text-gray-600 text-sm">
                  <MapPin className="w-4 h-4 mr-2 text-orange-500" />
                  {event.location}
                </div>
                <div className="flex items-center text-gray-600 text-sm">
                  <Users className="w-4 h-4 mr-2 text-orange-500" />
                  {event.attendees} participants attendus
                </div>
              </div>

              <div className="flex gap-3 mt-auto">
                <Button variant="outline" className="flex-1">
                  Détails
                </Button>
                <Button className="flex-1">Gérer</Button>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>);

}