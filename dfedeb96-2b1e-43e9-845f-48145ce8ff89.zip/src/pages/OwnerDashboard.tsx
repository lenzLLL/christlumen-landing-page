import React, { useEffect, useState } from 'react';
import { ChurchCard } from '../components/dashboard/ChurchCard';
import { Button } from '../components/ui/Button';
import { Plus, TrendingUp, Users, Heart } from 'lucide-react';
import { api } from '../utils/api';
import { Church } from '../types';
export function OwnerDashboard() {
  const [churches, setChurches] = useState<Church[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    api.church.list().then((data) => {
      setChurches(data);
      setLoading(false);
    });
  }, []);
  const stats = [
  {
    label: 'Membres Totaux',
    value: '1,295',
    change: '+12%',
    icon: Users,
    color: 'bg-blue-500'
  },
  {
    label: 'Dons ce mois',
    value: '850K FCFA',
    change: '+5%',
    icon: Heart,
    color: 'bg-pink-500'
  },
  {
    label: 'Croissance',
    value: '15%',
    change: '+2%',
    icon: TrendingUp,
    color: 'bg-green-500'
  }];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Tableau de bord</h1>
          <p className="text-gray-500">
            Bienvenue sur votre espace de gestion PHOTIZO.
          </p>
        </div>
        <Button leftIcon={<Plus className="w-4 h-4" />}>Nouvelle Église</Button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, index) =>
        <div
          key={index}
          className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center">
          
            <div className={`p-3 rounded-lg ${stat.color} bg-opacity-10`}>
              <stat.icon
              className={`w-6 h-6 ${stat.color.replace('bg-', 'text-')}`} />
            
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">{stat.label}</p>
              <div className="flex items-baseline gap-2">
                <h3 className="text-2xl font-bold text-gray-900">
                  {stat.value}
                </h3>
                <span className="text-xs font-medium text-green-600 bg-green-50 px-1.5 py-0.5 rounded-full">
                  {stat.change}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Churches List */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">
          Mes Églises
        </h2>
        {loading ?
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2].map((i) =>
          <div
            key={i}
            className="h-48 bg-gray-100 rounded-xl animate-pulse" />

          )}
          </div> :

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {churches.map((church) =>
          <ChurchCard key={church.id} church={church} />
          )}
          </div>
        }
      </div>
    </div>);

}