import React from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import {
  ShieldAlert,
  CheckCircle,
  Clock,
  MessageSquare,
  ArrowRight } from
'lucide-react';
import { Link } from 'react-router-dom';
import { Badge } from '../components/ui/Badge';
export function ModeratorDashboard() {
  const stats = [
  {
    label: 'En attente',
    value: '12',
    icon: Clock,
    color: 'text-orange-600',
    bg: 'bg-orange-50'
  },
  {
    label: 'Approuvés (24h)',
    value: '45',
    icon: CheckCircle,
    color: 'text-green-600',
    bg: 'bg-green-50'
  },
  {
    label: 'Signalements',
    value: '3',
    icon: ShieldAlert,
    color: 'text-red-600',
    bg: 'bg-red-50'
  },
  {
    label: 'Commentaires',
    value: '128',
    icon: MessageSquare,
    color: 'text-blue-600',
    bg: 'bg-blue-50'
  }];

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            Espace Modération
          </h1>
          <p className="text-gray-500">
            Gérez la qualité et la sécurité du contenu.
          </p>
        </div>
        <Button>Traiter la file d'attente</Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) =>
        <Card key={index} className="p-5 flex items-center gap-4">
            <div className={`p-3 rounded-xl ${stat.bg}`}>
              <stat.icon className={`w-6 h-6 ${stat.color}`} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">{stat.label}</p>
              <h3 className="text-2xl font-bold text-gray-900">{stat.value}</h3>
            </div>
          </Card>
        )}
      </div>

      {/* Priority Queue */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
          <h3 className="font-bold text-gray-900">
            Priorité Haute - Signalements
          </h3>
          <Link
            to="/dashboard/moderator/reports"
            className="text-sm text-orange-600 hover:text-orange-700 font-medium flex items-center">
            
            Voir tout <ArrowRight className="w-4 h-4 ml-1" />
          </Link>
        </div>
        <div className="divide-y divide-gray-100">
          {[1, 2, 3].map((i) =>
          <div
            key={i}
            className="p-4 sm:px-6 hover:bg-gray-50 transition-colors">
            
              <div className="flex items-start justify-between gap-4">
                <div className="flex gap-4">
                  <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0 text-red-600">
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">
                      Commentaire inapproprié signalé
                    </h4>
                    <p className="text-sm text-gray-500 mt-1">
                      Signalé par 3 utilisateurs • Il y a 2 heures
                    </p>
                    <div className="mt-2 p-3 bg-gray-50 rounded-lg text-sm text-gray-700 italic border border-gray-100">
                      "Ce contenu est vraiment offensant et ne devrait pas être
                      ici..."
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                  size="sm"
                  variant="outline"
                  className="text-red-600 hover:bg-red-50 border-red-200">
                  
                    Supprimer
                  </Button>
                  <Button size="sm" variant="outline">
                    Ignorer
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Content Approval Queue */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
          <h3 className="font-bold text-gray-900">
            Contenus en attente d'approbation
          </h3>
          <Link
            to="/dashboard/moderator/content-moderation"
            className="text-sm text-orange-600 hover:text-orange-700 font-medium flex items-center">
            
            Voir tout <ArrowRight className="w-4 h-4 ml-1" />
          </Link>
        </div>
        <div className="divide-y divide-gray-100">
          {[1, 2].map((i) =>
          <div
            key={i}
            className="p-4 sm:px-6 flex items-center justify-between hover:bg-gray-50 transition-colors">
            
              <div className="flex items-center gap-4">
                <div className="w-16 h-10 bg-gray-100 rounded-md"></div>
                <div>
                  <h4 className="font-medium text-gray-900">
                    Témoignage vidéo - Jean K.
                  </h4>
                  <p className="text-sm text-gray-500">
                    Soumis aujourd'hui à 10:30
                  </p>
                </div>
              </div>
              <Badge variant="warning">En attente</Badge>
            </div>
          )}
        </div>
      </div>
    </div>);

}