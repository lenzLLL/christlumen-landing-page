import { useState, useEffect } from 'react';
import { User } from '../types';
import { api, MOCK_USER } from '../utils/api';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Check for token
    const token = localStorage.getItem('token');
    if (token) {
      // In a real app, validate token with API
      setUser(MOCK_USER);
      setIsAuthenticated(true);
    }
    setLoading(false);
  }, []);

  const login = async (phone: string, otp: string) => {
    try {
      const response = await api.auth.verifyOtp(phone, otp);
      localStorage.setItem('token', response.token);
      setUser(response.user);
      setIsAuthenticated(true);
      return response.user;
    } catch (error) {
      throw error;
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
    setIsAuthenticated(false);
  };

  return {
    user,
    loading,
    isAuthenticated,
    login,
    logout
  };
}