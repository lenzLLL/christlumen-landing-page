import React from 'react';
import { Table } from '../ui/Table';
import { Member } from '../../types';
import { Badge } from '../ui/Badge';
import { MoreVertical } from 'lucide-react';
const MOCK_MEMBERS: Member[] = [
{
  id: '1',
  name: 'Alice Kouassi',
  role: 'Leader',
  joinedAt: '2023-01-15',
  status: 'ACTIVE'
},
{
  id: '2',
  name: 'Marc Koffi',
  role: 'Member',
  joinedAt: '2023-02-20',
  status: 'ACTIVE'
},
{
  id: '3',
  name: 'Sophie Yace',
  role: 'Assistant',
  joinedAt: '2023-03-10',
  status: 'BANNED'
}];

export function MemberTable() {
  return (
    <Table
      data={MOCK_MEMBERS}
      keyExtractor={(item) => item.id}
      columns={[
      {
        header: 'Membre',
        accessor: (item) =>
        <div className="flex items-center">
              <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center text-xs font-medium text-gray-600">
                {item.name.charAt(0)}
              </div>
              <div className="ml-3">
                <div className="text-sm font-medium text-gray-900">
                  {item.name}
                </div>
              </div>
            </div>

      },
      {
        header: 'Rôle',
        accessor: 'role'
      },
      {
        header: "Date d'adhésion",
        accessor: 'joinedAt'
      },
      {
        header: 'Statut',
        accessor: (item) =>
        <Badge variant={item.status === 'ACTIVE' ? 'success' : 'error'}>
              {item.status}
            </Badge>

      },
      {
        header: '',
        accessor: () =>
        <button className="text-gray-400 hover:text-gray-600">
              <MoreVertical className="w-4 h-4" />
            </button>,

        className: 'text-right'
      }]
      } />);


}