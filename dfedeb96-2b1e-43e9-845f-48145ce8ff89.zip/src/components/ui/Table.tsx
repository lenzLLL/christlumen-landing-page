import React from 'react';
interface Column<T> {
  header: string;
  accessor: keyof T | ((item: T) => React.ReactNode);
  className?: string;
}
interface TableProps<T> {
  data: T[];
  columns: Column<T>[];
  keyExtractor: (item: T) => string;
  onRowClick?: (item: T) => void;
  emptyMessage?: string;
}
export function Table<T>({
  data,
  columns,
  keyExtractor,
  onRowClick,
  emptyMessage = 'Aucune donnée disponible'
}: TableProps<T>) {
  return (
    <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            {columns.map((col, index) =>
            <th
              key={index}
              scope="col"
              className={`px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider ${col.className || ''}`}>
              
                {col.header}
              </th>
            )}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {data.length > 0 ?
          data.map((item) =>
          <tr
            key={keyExtractor(item)}
            onClick={() => onRowClick?.(item)}
            className={`
                  transition-colors
                  ${onRowClick ? 'cursor-pointer hover:bg-gray-50' : ''}
                `}>
            
                {columns.map((col, index) =>
            <td
              key={index}
              className={`px-6 py-4 whitespace-nowrap text-sm text-gray-900 ${col.className || ''}`}>
              
                    {typeof col.accessor === 'function' ?
              col.accessor(item) :
              item[col.accessor] as React.ReactNode}
                  </td>
            )}
              </tr>
          ) :

          <tr>
              <td
              colSpan={columns.length}
              className="px-6 py-12 text-center text-gray-500 text-sm">
              
                {emptyMessage}
              </td>
            </tr>
          }
        </tbody>
      </table>
    </div>);

}