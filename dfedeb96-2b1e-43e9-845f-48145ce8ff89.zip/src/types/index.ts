export type UserRole = 'SADMIN' | 'OWNER' | 'ADMIN' | 'MODERATOR' | 'USER';

export interface User {
  id: string;
  name: string;
  phoneNumber: string;
  role: UserRole;
  email?: string;
  avatarUrl?: string;
}

export interface Church {
  id: string;
  code: string;
  title: string;
  slug: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  logoUrl?: string;
  membersCount: number;
  city: string;
  country: string;
  description?: string;
}

export interface Content {
  id: string;
  title: string;
  type: 'ARTICLE' | 'AUDIO' | 'VIDEO' | 'EVENT' | 'POST' | 'BOOK';
  published: boolean;
  views: number;
  createdAt: string;
  coverUrl?: string;
}

export interface Member {
  id: string;
  name: string;
  role: string;
  joinedAt: string;
  status: 'ACTIVE' | 'BANNED';
  avatarUrl?: string;
}

export interface Metric {
  label: string;
  value: string | number;
  change: number;
  trend: 'up' | 'down' | 'neutral';
}