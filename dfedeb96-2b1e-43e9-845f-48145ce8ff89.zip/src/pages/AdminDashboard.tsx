import React from 'react';
import { Table } from '../components/ui/Table';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Check, X } from 'lucide-react';
const PENDING_CHURCHES = [
{
  id: '1',
  title: 'Église Nouvelle Vie',
  city: 'Bouaké',
  owner: 'Paul Konan',
  date: '2023-10-10'
},
{
  id: '2',
  title: 'Mission Salut',
  city: 'Daloa',
  owner: 'Jean Yao',
  date: '2023-10-11'
}];

export function AdminDashboard() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">
          Super Admin Dashboard
        </h1>
        <p className="text-gray-500">
          Gestion globale de la plateforme PHOTIZO.
        </p>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
        'Total Églises',
        'Utilisateurs',
        'Revenus (Mois)',
        'Églises en attente'].
        map((label, i) =>
        <div
          key={i}
          className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          
            <p className="text-sm font-medium text-gray-500">{label}</p>
            <p className="text-2xl font-bold text-gray-900 mt-2">
              {Math.floor(Math.random() * 1000)}
            </p>
          </div>
        )}
      </div>

      {/* Approval Queue */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
          <h3 className="font-semibold text-gray-900">
            Demandes d'approbation
          </h3>
          <Badge variant="warning">2 en attente</Badge>
        </div>
        <Table
          data={PENDING_CHURCHES}
          keyExtractor={(item) => item.id}
          columns={[
          {
            header: 'Église',
            accessor: 'title'
          },
          {
            header: 'Ville',
            accessor: 'city'
          },
          {
            header: 'Propriétaire',
            accessor: 'owner'
          },
          {
            header: 'Date',
            accessor: 'date'
          },
          {
            header: 'Actions',
            accessor: () =>
            <div className="flex gap-2 justify-end">
                  <Button
                size="sm"
                variant="ghost"
                className="text-green-600 hover:bg-green-50">
                
                    <Check className="w-4 h-4" />
                  </Button>
                  <Button
                size="sm"
                variant="ghost"
                className="text-red-600 hover:bg-red-50">
                
                    <X className="w-4 h-4" />
                  </Button>
                </div>,

            className: 'text-right'
          }]
          } />
        
      </div>
    </div>);

}