import React from 'react';
import { Content } from '../../types';
import { Card } from '../ui/Card';
import { Video, Mic, FileText, Calendar, Eye } from 'lucide-react';
const MOCK_CONTENT: Content[] = [
{
  id: '1',
  title: 'Culte du Dimanche',
  type: 'VIDEO',
  published: true,
  views: 1200,
  createdAt: '2023-10-01'
},
{
  id: '2',
  title: 'Étude Biblique',
  type: 'AUDIO',
  published: true,
  views: 450,
  createdAt: '2023-10-03'
},
{
  id: '3',
  title: 'Annonces de la semaine',
  type: 'ARTICLE',
  published: false,
  views: 0,
  createdAt: '2023-10-05'
}];

const icons = {
  VIDEO: Video,
  AUDIO: Mic,
  ARTICLE: FileText,
  EVENT: Calendar,
  POST: FileText,
  BOOK: FileText
};
export function ContentList() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {MOCK_CONTENT.map((item) => {
        const Icon = icons[item.type];
        return (
          <Card key={item.id} className="hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between">
              <div
                className={`p-2 rounded-lg ${item.published ? 'bg-blue-50 text-blue-600' : 'bg-gray-100 text-gray-500'}`}>
                
                <Icon className="w-5 h-5" />
              </div>
              <span
                className={`text-xs font-medium px-2 py-1 rounded-full ${item.published ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                
                {item.published ? 'Publié' : 'Brouillon'}
              </span>
            </div>
            <h4 className="mt-4 font-medium text-gray-900">{item.title}</h4>
            <div className="mt-4 flex items-center justify-between text-sm text-gray-500">
              <span>{item.createdAt}</span>
              <div className="flex items-center">
                <Eye className="w-4 h-4 mr-1" />
                {item.views}
              </div>
            </div>
          </Card>);

      })}
    </div>);

}