import React, { useEffect, useState, useRef } from 'react';
interface OTPInputProps {
  length?: number;
  onComplete: (otp: string) => void;
  error?: string;
}
export function OTPInput({ length = 6, onComplete, error }: OTPInputProps) {
  const [otp, setOtp] = useState<string[]>(new Array(length).fill(''));
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  useEffect(() => {
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, []);
  const handleChange = (element: HTMLInputElement, index: number) => {
    if (isNaN(Number(element.value))) return false;
    const newOtp = [...otp];
    newOtp[index] = element.value;
    setOtp(newOtp);
    // Focus next input
    if (element.value !== '' && index < length - 1) {
      inputRefs.current[index + 1]?.focus();
    }
    // Trigger callback if complete
    if (newOtp.every((digit) => digit !== '')) {
      onComplete(newOtp.join(''));
    }
  };
  const handleKeyDown = (
  e: React.KeyboardEvent<HTMLInputElement>,
  index: number) =>
  {
    if (e.key === 'Backspace') {
      if (index > 0 && otp[index] === '') {
        inputRefs.current[index - 1]?.focus();
        const newOtp = [...otp];
        newOtp[index - 1] = '';
        setOtp(newOtp);
      } else {
        const newOtp = [...otp];
        newOtp[index] = '';
        setOtp(newOtp);
      }
    }
  };
  return (
    <div className="w-full">
      <div className="flex gap-2 sm:gap-3 justify-center">
        {otp.map((data, index) =>
        <input
          key={index}
          ref={(el) => inputRefs.current[index] = el}
          type="text"
          maxLength={1}
          className={`
              w-11 h-14 sm:w-14 sm:h-16 text-center text-2xl font-bold rounded-xl border-2 
              outline-none transition-all duration-200 shadow-sm
              ${error ? 'border-red-300 text-red-600 bg-red-50 focus:ring-4 focus:ring-red-100' : 'border-gray-200 text-gray-900 bg-white hover:border-gray-300 focus:border-[#FF6B35] focus:ring-4 focus:ring-[#FF6B35]/10'}
            `}
          value={data}
          onChange={(e) => handleChange(e.target, index)}
          onKeyDown={(e) => handleKeyDown(e, index)} />

        )}
      </div>
      {error &&
      <p className="mt-3 text-center text-sm text-red-600 font-medium animate-in slide-in-from-top-1">
          {error}
        </p>
      }
    </div>);

}