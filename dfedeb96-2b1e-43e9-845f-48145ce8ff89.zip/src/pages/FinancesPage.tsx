import React from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Table } from '../components/ui/Table';
import { Badge } from '../components/ui/Badge';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  CreditCard,
  Download,
  Calendar } from
'lucide-react';
const TRANSACTIONS = [
{
  id: '1',
  donor: 'Jean Kouassi',
  amount: '50,000 FCFA',
  type: 'Dîme',
  date: '2023-11-15',
  status: 'COMPLETED'
},
{
  id: '2',
  donor: 'Marie Doumbia',
  amount: '10,000 FCFA',
  type: 'Offrande',
  date: '2023-11-15',
  status: 'COMPLETED'
},
{
  id: '3',
  donor: 'Anonyme',
  amount: '100,000 FCFA',
  type: 'Don Spécial',
  date: '2023-11-14',
  status: 'COMPLETED'
},
{
  id: '4',
  donor: 'Paul Konan',
  amount: '25,000 FCFA',
  type: 'Dîme',
  date: '2023-11-14',
  status: 'PENDING'
},
{
  id: '5',
  donor: 'Sarah Yapo',
  amount: '5,000 FCFA',
  type: 'Offrande',
  date: '2023-11-13',
  status: 'COMPLETED'
}];

export function FinancesPage() {
  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Finances</h1>
          <p className="text-gray-500">Aperçu des dons et transactions.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" leftIcon={<Calendar className="w-4 h-4" />}>
            Ce mois
          </Button>
          <Button variant="outline" leftIcon={<Download className="w-4 h-4" />}>
            Exporter
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-green-50 rounded-lg">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
            <span className="text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full flex items-center">
              <TrendingUp className="w-3 h-3 mr-1" /> +12%
            </span>
          </div>
          <p className="text-sm text-gray-500">Revenus ce mois</p>
          <h3 className="text-2xl font-bold text-gray-900 mt-1">
            2,450,000 FCFA
          </h3>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-blue-50 rounded-lg">
              <CreditCard className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded-full flex items-center">
              <TrendingUp className="w-3 h-3 mr-1" /> +5%
            </span>
          </div>
          <p className="text-sm text-gray-500">Nombre de dons</p>
          <h3 className="text-2xl font-bold text-gray-900 mt-1">145</h3>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-orange-50 rounded-lg">
              <TrendingUp className="w-6 h-6 text-orange-600" />
            </div>
            <span className="text-xs font-medium text-gray-600 bg-gray-50 px-2 py-1 rounded-full flex items-center">
              Stable
            </span>
          </div>
          <p className="text-sm text-gray-500">Don moyen</p>
          <h3 className="text-2xl font-bold text-gray-900 mt-1">16,800 FCFA</h3>
        </Card>
      </div>

      {/* Recent Transactions */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100">
          <h3 className="font-semibold text-gray-900">Transactions récentes</h3>
        </div>
        <Table
          data={TRANSACTIONS}
          keyExtractor={(item) => item.id}
          columns={[
          {
            header: 'Donateur',
            accessor: 'donor',
            className: 'font-medium text-gray-900'
          },
          {
            header: 'Type',
            accessor: 'type'
          },
          {
            header: 'Montant',
            accessor: 'amount',
            className: 'font-bold'
          },
          {
            header: 'Date',
            accessor: 'date'
          },
          {
            header: 'Statut',
            accessor: (item) =>
            <Badge
              variant={item.status === 'COMPLETED' ? 'success' : 'warning'}>
              
                  {item.status === 'COMPLETED' ? 'Complété' : 'En attente'}
                </Badge>

          }]
          } />
        
      </div>
    </div>);

}