import React from 'react';
import { Menu, Bell, Search, ChevronDown } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
interface TopBarProps {
  onMenuClick: () => void;
}
export function TopBar({ onMenuClick }: TopBarProps) {
  const { user } = useAuth();
  return (
    <header className="bg-white border-b border-gray-200 h-16 flex items-center justify-between px-4 sm:px-6 lg:px-8 sticky top-0 z-30">
      <div className="flex items-center">
        <button
          onClick={onMenuClick}
          className="lg:hidden p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-[#FF6B35]">
          
          <Menu className="h-6 w-6" />
        </button>

        {/* Search bar - hidden on mobile */}
        <div className="hidden md:flex ml-4 items-center bg-gray-50 rounded-lg px-3 py-2 w-64 border border-gray-200 focus-within:ring-2 focus-within:ring-[#FF6B35] focus-within:border-transparent transition-all">
          <Search className="h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Rechercher..."
            className="bg-transparent border-none focus:ring-0 text-sm ml-2 w-full text-gray-900 placeholder-gray-500" />
          
        </div>
      </div>

      <div className="flex items-center gap-4">
        <button className="p-2 rounded-full text-gray-400 hover:text-gray-500 hover:bg-gray-100 relative">
          <Bell className="h-5 w-5" />
          <span className="absolute top-1.5 right-1.5 h-2 w-2 bg-red-500 rounded-full ring-2 ring-white"></span>
        </button>

        <div className="relative flex items-center gap-3 pl-4 border-l border-gray-200">
          <div className="hidden sm:block text-right">
            <p className="text-sm font-medium text-gray-900">{user?.name}</p>
            <p className="text-xs text-gray-500 capitalize">
              {user?.role.toLowerCase()}
            </p>
          </div>
          <img
            className="h-8 w-8 rounded-full ring-2 ring-white shadow-sm object-cover"
            src={
            user?.avatarUrl ||
            `https://ui-avatars.com/api/?name=${user?.name}&background=random`
            }
            alt={user?.name} />
          
          <ChevronDown className="h-4 w-4 text-gray-400 hidden sm:block" />
        </div>
      </div>
    </header>);

}