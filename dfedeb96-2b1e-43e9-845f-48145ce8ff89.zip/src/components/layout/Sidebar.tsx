import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Church,
  Users,
  FileText,
  Calendar,
  CreditCard,
  Settings,
  LogOut,
  ShieldCheck,
  ShieldAlert,
  Heart,
  User,
  Home } from
'lucide-react';
import { useAuth } from '../../hooks/useAuth';
interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}
export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const { user, logout } = useAuth();
  // SADMIN Links
  const adminLinks = [
  {
    name: 'Global Overview',
    to: '/dashboard/admin',
    icon: LayoutDashboard,
    end: true
  },
  {
    name: 'Approbations',
    to: '/dashboard/admin/approvals',
    icon: ShieldCheck
  },
  {
    name: 'Toutes les Églises',
    to: '/dashboard/admin/churches',
    icon: Church
  },
  {
    name: 'Utilisateurs',
    to: '/dashboard/admin/users',
    icon: Users
  },
  {
    name: 'Revenus',
    to: '/dashboard/admin/revenue',
    icon: CreditCard
  }];

  // OWNER Links
  const ownerLinks = [
  {
    name: "Vue d'ensemble",
    to: '/dashboard/owner',
    icon: LayoutDashboard,
    end: true
  },
  {
    name: 'Mes Églises',
    to: '/dashboard/owner/churches',
    icon: Church
  },
  {
    name: 'Membres',
    to: '/dashboard/owner/members',
    icon: Users
  },
  {
    name: 'Contenus',
    to: '/dashboard/owner/content',
    icon: FileText
  },
  {
    name: 'Événements',
    to: '/dashboard/owner/events',
    icon: Calendar
  },
  {
    name: 'Finances',
    to: '/dashboard/owner/finances',
    icon: CreditCard
  },
  {
    name: 'Paramètres',
    to: '/dashboard/owner/settings',
    icon: Settings
  }];

  // ADMIN (Church Admin) Links
  const churchAdminLinks = [
  {
    name: "Vue d'ensemble",
    to: '/dashboard/church-admin',
    icon: LayoutDashboard,
    end: true
  },
  {
    name: 'Membres',
    to: '/dashboard/church-admin/members',
    icon: Users
  },
  {
    name: 'Contenus',
    to: '/dashboard/church-admin/content',
    icon: FileText
  },
  {
    name: 'Événements',
    to: '/dashboard/church-admin/events',
    icon: Calendar
  },
  {
    name: 'Finances',
    to: '/dashboard/church-admin/finances',
    icon: CreditCard
  },
  {
    name: 'Paramètres',
    to: '/dashboard/church-admin/settings',
    icon: Settings
  }];

  // MODERATOR Links
  const moderatorLinks = [
  {
    name: "Vue d'ensemble",
    to: '/dashboard/moderator',
    icon: LayoutDashboard,
    end: true
  },
  {
    name: 'Modération',
    to: '/dashboard/moderator/content-moderation',
    icon: ShieldCheck
  },
  {
    name: 'Signalements',
    to: '/dashboard/moderator/reports',
    icon: ShieldAlert
  }];

  // USER (Member) Links
  const memberLinks = [
  {
    name: 'Mon Feed',
    to: '/dashboard/member',
    icon: Home,
    end: true
  },
  {
    name: 'Événements',
    to: '/dashboard/member/events',
    icon: Calendar
  },
  {
    name: 'Mes Dons',
    to: '/dashboard/member/giving',
    icon: Heart
  },
  {
    name: 'Mon Profil',
    to: '/dashboard/member/profile',
    icon: User
  }];

  // Determine which links to show based on role
  let links = memberLinks; // Default to member links
  if (user?.role === 'SADMIN') links = adminLinks;else
  if (user?.role === 'OWNER') links = ownerLinks;else
  if (user?.role === 'ADMIN') links = churchAdminLinks;else
  if (user?.role === 'MODERATOR') links = moderatorLinks;
  return (
    <>
      {/* Mobile overlay */}
      <div
        className={`fixed inset-0 bg-gray-900/50 z-40 lg:hidden transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose} />
      

      {/* Sidebar */}
      <div
        className={`
        fixed top-0 left-0 bottom-0 w-64 bg-white border-r border-gray-200 z-50 transform transition-transform duration-300 ease-in-out
        lg:translate-x-0 lg:static lg:h-screen
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        
        <div className="h-16 flex items-center px-6 border-b border-gray-100">
          <img
            src="/ChatGPT_Image_14_janv._2026,_15_43_53.png"
            alt="Logo"
            className="h-8 w-auto mr-3" />
          
          <span className="font-bold text-lg bg-clip-text text-transparent bg-gradient-to-r from-[#FF6B35] to-[#E91E63]">
            PHOTIZO
          </span>
        </div>

        <nav className="p-4 space-y-1 overflow-y-auto h-[calc(100vh-4rem)] flex flex-col">
          <div className="flex-1 space-y-1">
            {links.map((link) =>
            <NavLink
              key={link.to}
              to={link.to}
              end={link.end}
              onClick={() => window.innerWidth < 1024 && onClose()}
              className={({ isActive }) => `
                  flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200
                  ${isActive ? 'bg-[#FF6B35]/10 text-[#FF6B35]' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'}
                `}>
              
                <link.icon className={`mr-3 h-5 w-5 flex-shrink-0`} />
                {link.name}
              </NavLink>
            )}
          </div>

          <div className="pt-4 mt-4 border-t border-gray-100">
            <div className="px-4 py-3 mb-2 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-gray-100 overflow-hidden">
                {user?.avatarUrl ?
                <img
                  src={user.avatarUrl}
                  alt={user.name}
                  className="w-full h-full object-cover" /> :


                <User className="w-full h-full p-1 text-gray-400" />
                }
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">
                  {user?.name || 'Utilisateur'}
                </p>
                <p className="text-xs text-gray-500 truncate">
                  {user?.role || 'Membre'}
                </p>
              </div>
            </div>
            <button
              onClick={logout}
              className="flex w-full items-center px-4 py-3 text-sm font-medium text-red-600 rounded-lg hover:bg-red-50 transition-colors">
              
              <LogOut className="mr-3 h-5 w-5" />
              Déconnexion
            </button>
          </div>
        </nav>
      </div>
    </>);

}