import { User, Church } from '../types';

// Mock data
export const MOCK_USER: User = {
  id: '1',
  name: 'Jean Baptiste',
  phoneNumber: '+2250707070707',
  role: 'OWNER',
  avatarUrl:
  'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80'
};

export const MOCK_CHURCHES: Church[] = [
{
  id: '1',
  code: 'CH001',
  title: 'Église La Compassion',
  slug: 'eglise-la-compassion',
  status: 'APPROVED',
  membersCount: 1250,
  city: 'Abidjan',
  country: "Côte d'Ivoire",
  logoUrl:
  'https://images.unsplash.com/photo-1548625361-18886594294d?auto=format&fit=crop&q=80&w=150&h=150',
  description: "Une communauté vibrante au cœur d'Abidjan."
},
{
  id: '2',
  code: 'CH002',
  title: 'Centre Chrétien Espoir',
  slug: 'centre-chretien-espoir',
  status: 'PENDING',
  membersCount: 45,
  city: 'Yaoundé',
  country: 'Cameroun',
  description: 'Nouvelle implantation à Yaoundé.'
}];


// Simple delay helper
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export const api = {
  auth: {
    sendOtp: async (phone: string) => {
      await delay(1000);
      return { success: true, message: 'OTP sent' };
    },
    verifyOtp: async (phone: string, otp: string) => {
      await delay(1000);
      if (otp === '123456') {
        return { success: true, token: 'mock-jwt-token', user: MOCK_USER };
      }
      throw new Error('Code OTP invalide');
    }
  },
  user: {
    me: async () => {
      await delay(500);
      return MOCK_USER;
    }
  },
  church: {
    list: async () => {
      await delay(800);
      return MOCK_CHURCHES;
    },
    get: async (id: string) => {
      await delay(500);
      return MOCK_CHURCHES.find((c) => c.id === id);
    }
  }
};