import React from 'react';
import { Table } from '../components/ui/Table';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Check, X, Eye, AlertTriangle } from 'lucide-react';
const PENDING_CONTENT = [
{
  id: '1',
  title: 'Témoignage de guérison',
  type: 'VIDEO',
  author: 'Jean K.',
  date: '2023-11-15',
  status: 'PENDING',
  risk: 'LOW'
},
{
  id: '2',
  title: 'Commentaire sur le culte',
  type: 'COMMENT',
  author: 'Anonyme',
  date: '2023-11-15',
  status: 'REPORTED',
  risk: 'HIGH'
},
{
  id: '3',
  title: 'Photo événement jeunesse',
  type: 'IMAGE',
  author: 'Sarah Y.',
  date: '2023-11-14',
  status: 'PENDING',
  risk: 'LOW'
},
{
  id: '4',
  title: 'Article de blog invité',
  type: 'ARTICLE',
  author: 'Paul M.',
  date: '2023-11-14',
  status: 'PENDING',
  risk: 'MEDIUM'
}];

export function ContentModerationPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            Modération de Contenu
          </h1>
          <p className="text-gray-500">
            Examinez et validez les contenus soumis.
          </p>
        </div>
        <div className="flex gap-2">
          <Badge variant="warning" className="text-sm px-3 py-1">
            12 En attente
          </Badge>
          <Badge variant="danger" className="text-sm px-3 py-1">
            3 Signalés
          </Badge>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <Table
          data={PENDING_CONTENT}
          keyExtractor={(item) => item.id}
          columns={[
          {
            header: 'Contenu',
            accessor: (item) =>
            <div>
                  <p className="font-medium text-gray-900">{item.title}</p>
                  <p className="text-xs text-gray-500">
                    {item.type} • Par {item.author}
                  </p>
                </div>

          },
          {
            header: 'Date',
            accessor: 'date'
          },
          {
            header: 'Statut',
            accessor: (item) =>
            <Badge
              variant={item.status === 'REPORTED' ? 'danger' : 'warning'}>
              
                  {item.status === 'REPORTED' ? 'Signalé' : 'En attente'}
                </Badge>

          },
          {
            header: 'Risque',
            accessor: (item) =>
            <div className="flex items-center gap-1">
                  {item.risk === 'HIGH' &&
              <AlertTriangle className="w-3 h-3 text-red-500" />
              }
                  <span
                className={`text-xs font-medium ${item.risk === 'HIGH' ? 'text-red-600' : item.risk === 'MEDIUM' ? 'text-orange-600' : 'text-green-600'}`}>
                
                    {item.risk === 'HIGH' ?
                'Élevé' :
                item.risk === 'MEDIUM' ?
                'Moyen' :
                'Faible'}
                  </span>
                </div>

          },
          {
            header: 'Actions',
            accessor: () =>
            <div className="flex justify-end gap-2">
                  <Button
                size="sm"
                variant="ghost"
                className="text-gray-500 hover:text-blue-600 hover:bg-blue-50">
                
                    <Eye className="w-4 h-4" />
                  </Button>
                  <Button
                size="sm"
                variant="ghost"
                className="text-green-600 hover:bg-green-50">
                
                    <Check className="w-4 h-4" />
                  </Button>
                  <Button
                size="sm"
                variant="ghost"
                className="text-red-600 hover:bg-red-50">
                
                    <X className="w-4 h-4" />
                  </Button>
                </div>,

            className: 'text-right'
          }]
          } />
        
      </div>
    </div>);

}