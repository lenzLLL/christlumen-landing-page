import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { PhoneInput } from '../components/auth/PhoneInput';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { ArrowRight, Check, Sparkles, User, Mail, Church } from 'lucide-react';
export function SignupPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    churchName: '',
    acceptedTerms: false
  });
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.acceptedTerms) return;
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      navigate('/dashboard/owner');
    }, 1500);
  };
  const benefits = [
  'Gestion complète de vos membres',
  'Communication ciblée et efficace',
  'Dons et paiements simplifiés'];

  return (
    <div className="min-h-screen flex w-full bg-white overflow-hidden">
      {/* Left Side - Image & Benefits */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-gray-900">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1504052434569-70ad5836ab65?auto=format&fit=crop&q=80&w=1200&h=1800"
            alt="Church Community"
            className="w-full h-full object-cover opacity-60" />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent" />
        </div>

        <div className="relative z-10 flex flex-col justify-between w-full p-16 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold tracking-wider">PHOTIZO</span>
          </div>

          <div className="space-y-8 max-w-lg">
            <h1 className="text-4xl font-bold leading-tight">
              Créez votre communauté digitale aujourd'hui.
            </h1>

            <div className="space-y-4">
              {benefits.map((benefit, index) =>
              <div key={index} className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-[#FF6B35] flex items-center justify-center flex-shrink-0">
                    <Check className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-lg text-white/90">{benefit}</span>
                </div>
              )}
            </div>
          </div>

          <div className="text-sm text-white/60">
            <p>© 2026 Photizo App. Tous droits réservés.</p>
          </div>
        </div>
      </div>

      {/* Right Side - Signup Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12 bg-white relative overflow-y-auto">
        {/* Mobile Header Background */}
        <div className="lg:hidden absolute top-0 left-0 w-full h-32 bg-gradient-to-br from-[#FF6B35] to-[#E91E63]"></div>

        <div className="w-full max-w-md space-y-8 relative z-10 mt-10 lg:mt-0">
          <div className="text-center lg:text-left">
            <motion.div
              initial={{
                opacity: 0,
                y: 20
              }}
              animate={{
                opacity: 1,
                y: 0
              }}
              transition={{
                duration: 0.5
              }}>
              
              <div className="flex justify-center lg:justify-start mb-6">
                <img
                  src="/ChatGPT_Image_14_janv._2026,_15_43_53.png"
                  alt="PHOTIZO"
                  className="h-16 w-auto drop-shadow-sm bg-white rounded-xl p-1" />
                
              </div>

              <h2 className="text-3xl font-bold text-gray-900 tracking-tight">
                Créer votre compte
              </h2>
              <p className="mt-2 text-gray-500">
                Commencez gratuitement, sans carte bancaire.
              </p>
            </motion.div>
          </div>

          <motion.form
            initial={{
              opacity: 0,
              y: 20
            }}
            animate={{
              opacity: 1,
              y: 0
            }}
            transition={{
              duration: 0.5,
              delay: 0.1
            }}
            className="space-y-5"
            onSubmit={handleSubmit}>
            
            <div className="space-y-4">
              <Input
                label="Nom complet"
                placeholder="Jean Kouassi"
                leftIcon={<User className="w-5 h-5" />}
                value={formData.name}
                onChange={(e) =>
                setFormData({
                  ...formData,
                  name: e.target.value
                })
                }
                required />
              

              <Input
                label="Email professionnel"
                type="email"
                placeholder="jean@eglise.com"
                leftIcon={<Mail className="w-5 h-5" />}
                value={formData.email}
                onChange={(e) =>
                setFormData({
                  ...formData,
                  email: e.target.value
                })
                }
                required />
              

              <PhoneInput
                value={formData.phone}
                onChange={(value) =>
                setFormData({
                  ...formData,
                  phone: value
                })
                } />
              

              <Input
                label="Nom de votre église (Optionnel)"
                placeholder="Église La Compassion"
                leftIcon={<Church className="w-5 h-5" />}
                value={formData.churchName}
                onChange={(e) =>
                setFormData({
                  ...formData,
                  churchName: e.target.value
                })
                } />
              
            </div>

            <div className="flex items-start gap-3 pt-2">
              <div className="flex items-center h-5">
                <input
                  id="terms"
                  name="terms"
                  type="checkbox"
                  className="h-4 w-4 text-[#FF6B35] focus:ring-[#FF6B35] border-gray-300 rounded cursor-pointer"
                  checked={formData.acceptedTerms}
                  onChange={(e) =>
                  setFormData({
                    ...formData,
                    acceptedTerms: e.target.checked
                  })
                  }
                  required />
                
              </div>
              <div className="text-sm">
                <label
                  htmlFor="terms"
                  className="font-medium text-gray-700 cursor-pointer">
                  
                  J'accepte les conditions d'utilisation
                </label>
                <p className="text-gray-500">
                  En créant un compte, vous acceptez nos CGU et notre politique
                  de confidentialité.
                </p>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full h-12 text-base shadow-lg shadow-orange-500/20 hover:shadow-orange-500/30 transition-all duration-300"
              isLoading={isLoading}
              disabled={!formData.acceptedTerms}
              rightIcon={<ArrowRight className="w-5 h-5 ml-1" />}>
              
              Créer mon compte
            </Button>

            <div className="text-center pt-4">
              <p className="text-sm text-gray-600">
                Déjà un compte ?{' '}
                <Link
                  to="/login"
                  className="font-semibold text-[#FF6B35] hover:text-[#E91E63] transition-colors">
                  
                  Se connecter
                </Link>
              </p>
            </div>
          </motion.form>
        </div>
      </div>
    </div>);

}