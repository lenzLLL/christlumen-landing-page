import React from 'react';
import { Phone } from 'lucide-react';
interface PhoneInputProps {
  value: string;
  onChange: (value: string) => void;
  error?: string;
}
export function PhoneInput({ value, onChange, error }: PhoneInputProps) {
  return (
    <div className="w-full">
      <label className="block text-sm font-semibold text-gray-700 mb-2">
        Numéro de téléphone
      </label>
      <div className="relative flex items-center">
        <div className="absolute left-0 top-0 bottom-0 flex items-center pl-4 pointer-events-none z-10">
          <Phone className="h-5 w-5 text-gray-400" />
          <span className="ml-2 text-gray-500 font-medium border-r border-gray-200 pr-3 mr-3 h-6 flex items-center">
            +225
          </span>
        </div>
        <input
          type="tel"
          className={`
            block w-full pl-24 pr-4 py-3.5 rounded-xl border bg-white
            text-gray-900 placeholder-gray-400 font-medium transition-all duration-200
            focus:outline-none focus:ring-2 focus:ring-offset-0
            ${error ? 'border-red-300 focus:border-red-500 focus:ring-red-100' : 'border-gray-200 hover:border-gray-300 focus:border-[#FF6B35] focus:ring-[#FF6B35]/20'}
          `}
          placeholder="07 07 07 07 07"
          value={value}
          onChange={(e) => onChange(e.target.value)} />
        
      </div>
      {error &&
      <p className="mt-2 text-sm text-red-600 flex items-center animate-in slide-in-from-top-1">
          <span className="w-1 h-1 rounded-full bg-red-600 mr-2"></span>
          {error}
        </p>
      }
    </div>);

}